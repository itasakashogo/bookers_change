class RootController < ApplicationController
  def top
  	
  end
end
