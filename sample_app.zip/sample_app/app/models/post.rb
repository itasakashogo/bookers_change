class Post < ApplicationRecord
	 attachment :image
end
