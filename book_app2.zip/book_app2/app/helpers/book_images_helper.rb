module BookImagesHelper
end
