
class Book < ApplicationRecord

end

