require 'test_helper'

class BookImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
