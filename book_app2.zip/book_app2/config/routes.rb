Rails.application.routes.draw do
  devise_for :users
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  resources :books
  root to: 'books#root'
  resources :users, only: [:show, :edit, :update]
  resources :book_images, only:[:new, :create, :index, :show, :destroy]


end

